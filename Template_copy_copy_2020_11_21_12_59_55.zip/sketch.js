
var monkey, monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var foodGroup, obstacleGroup;
var monkey2, monkey2Image;
var score;
var ground;
var fd;
var play=1;

var end=0;
var gameState=play;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
  monkey2Image=loadImage("sprite_2.png");
  
  
}



function setup() {
  createCanvas(500,240);
  
  monkey = createSprite(50,200,40,50);
  monkey.scale = 0.1;
  monkey.addAnimation("running", monkey_running);
  
  ground= createSprite(250,220,500,20)
  ground.shapeColor="lightblue"
  
  
  

  
  foodGroup = createGroup();
  obstacleGroup=createGroup();
  score=0;
}


function draw() {
  background("lightblue");
   
  text("Score: "+ score, 400,50);
  
  
  if(gameState===play){
    if(keyDown("space")&& monkey.y >= 100) {
        monkey.velocityY = -12;
        
    }
  
monkey.velocityY = monkey.velocityY + 0.8;
    if (monkey.isTouching(foodGroup)) {
      foodGroup.destroyEach();
      score = score + 5;
     
    }
    if (monkey.isTouching(obstacleGroup)) {
    
    gameState=end;
    
    
  }
    food();
  obstacles();
  }
  else if (gameState===end){
    foodGroup.destroyEach();
    obstacleGroup.destroyEach();
    textSize(35);
    text("GAME OVER",150,120)
   
    
   monkey.visible=false
  }
   
   monkey.collide(ground);
  
  
  
  
  
  
  
 
  drawSprites();
}
function food(){
  if(frameCount%80===0){
     fd=createSprite(400,50,10,10);
    fd.addImage(bananaImage);
    fd.scale=0.1;
    fd.velocityX = -3;
    fd.lifetime=200;
    foodGroup.add(fd);
  }
}
function obstacles(){
  if(frameCount%80===0){
     rock=createSprite(250,200,10,10);
    rock.addImage(obstacleImage);
    rock.scale=0.1;
    rock.velocityX = -3;
    rock.lifetime=200;
    obstacleGroup.add(rock);
  }
  
}




